import React from 'react';

const Dashboard = () => {
  // Dummy data for recommended courses
  const recommendedCourses = [
    { id: 1, title: 'Introduction to Machine Learning', progress: 75 },
    { id: 2, title: 'Advanced React.js', progress: 50 },
    { id: 3, title: 'Data Structures and Algorithms', progress: 30 }
  ];

  return (
    <div className="dashboard">
      <h2>Dashboard</h2>
      <h3>Recommended Courses</h3>
      <ul>
        {recommendedCourses.map(course => (
          <li key={course.id}>
            {course.title} - {course.progress}% completed
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Dashboard;